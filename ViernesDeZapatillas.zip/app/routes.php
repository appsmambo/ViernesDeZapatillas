<?php

Route::get('/', 'HomeController@index');

