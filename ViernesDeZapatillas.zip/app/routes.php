<?php

Route::get('/', 'HomeController@index');
Route::get('/calendario', 'HomeController@calendario');

Route::get('/twitterTest', 'HomeController@twTest');