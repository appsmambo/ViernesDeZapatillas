<?php

class HomeController extends BaseController {
	
	private $_video = 'D9lXtYgD21s';

	public function index()
	{
		return View::make('index')->with('videoCampana', $this->_video)->with('calendario', '0');
	}
	public function calendario()
	{
		return View::make('index')->with('videoCampana', $this->_video)->with('calendario', '1');
	}
	public function twTest()
	{
		$images = array();
		$max_id = 0;
        $totalTweets = 5;
        $responset = Twitter::getSearch(array('q' => '#viernesdezapatillas since:2015-07-01 filter:images', 'count' => $totalTweets, 'max_id' => $max_id, 'since_id' => 0));
        foreach ($responset->statuses as $tweet) {
            foreach ($tweet->entities->media as $url) {
                $images[] = $url->media_url . ':thumb';
            }
        }
		print_r($images);
	}

}
