<?php

// You can find the keys here : https://apps.twitter.com/

return [
	'debug'               => false,

	'API_URL'             => 'api.twitter.com',
	'UPLOAD_URL'          => 'upload.twitter.com',
	'API_VERSION'         => '1.1',
	'AUTHENTICATE_URL'    => 'https://api.twitter.com/oauth/authenticate',
	'AUTHORIZE_URL'       => 'https://api.twitter.com/oauth/authorize',
	'ACCESS_TOKEN_URL'    => 'https://api.twitter.com/oauth/access_token',
	'REQUEST_TOKEN_URL'   => 'https://api.twitter.com/oauth/request_token',
	'USE_SSL'             => true,

	'CONSUMER_KEY'        => 'eyn8MCwGCUJ7PTA2VRG7ALGhW',
	'CONSUMER_SECRET'     => 'GimM0UO2afiiYMmawaLU5zRcIxeWj2VMcsSGYUizt0mVepOQTr',
	'ACCESS_TOKEN'        => '8526422-SFFnRuegkA2yrzwUEYy80JFzrq4YwjcIEIOUkbrBCG',
	'ACCESS_TOKEN_SECRET' => '0yNzsBpHNbRKR7JHoSWD3Q089IMtpZkaeRE9yanzL9AGa',
];